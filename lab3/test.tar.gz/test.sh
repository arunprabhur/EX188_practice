#!/bin/bash

echo "Starting script"

sleep 1
ARG=$1

while(true)
do
	echo "Hello ${1} -- ${2}"
	sleep 1
done
